import React from "react";

const Stock = () => {
  return (
    <div>
      <h1>주식</h1>
      <p>여기는 주식페이지 입니다.</p>
    </div>
  );
};

export default Stock;
