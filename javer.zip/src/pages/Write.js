import React from "react";

const Write = () => {
  return <div>hello</div>;
};

export default Write;
