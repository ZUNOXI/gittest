import React from "react";

const Coin = () => {
  return (
    <div>
      <h1>Coin임</h1>
    </div>
  );
};

export default Coin;
