import React from "react";

const Fund = () => {
  return (
    <div>
      <h1>여기는 펀드영</h1>
    </div>
  );
};

export default Fund;
